# To update
`pip download Flask[async] -d .\async\` to download the dependencies
`pip install --no-index --find-links=.\async Flask[async]` to install the downloaded wheels
